import UIKit

///////// functions ///////////


func greet(person:String)->String
{
   let greeting="Hello"+person+"!"
    print(greeting)
    return greeting
}
greet(person: "Abc")

